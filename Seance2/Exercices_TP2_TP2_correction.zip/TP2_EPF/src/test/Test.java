package test;

import java.util.ArrayList;
import java.util.List;

import vehicule.*;

public class Test {

	public static void main(String [] args) {
		/* Le code commenté ci-dessous ne fonctionne plus car Vehicule est devenu une classe abstriate */
//		Vehicule vehicule = new Vehicule("Clio", 2, 750.0f);
//		System.out.println(vehicule);

		System.out.println("Nombre de véhicules : " + Vehicule.getNbVehicule());
		Voiture voiture = new Voiture("Clio", 2, 750.0f, 3, Propulsion.ESSENCE, 500);
//		System.out.println(voiture);

		Avion avion = new Avion("SuperAvion", 2, 7500.0f, 3000);
//		System.out.println(avion);

		System.out.println("Nombre de véhicules : " + Vehicule.getNbVehicule());
		Planeur planeur = new Planeur("planeur3000", 1, 100.0f, 1500);
//		System.out.println(planeur);

		Chasseur chasseur = new Chasseur("Chasseur", 2, 580.4f, 34, 420);
//		System.out.println(chasseur);

		System.out.println("Nombre de véhicules : " + Vehicule.getNbVehicule());


		/* ************************************** */


		List<Vehicule> list = new ArrayList<>();
		list.add(voiture);
		list.add(avion);
		list.add(chasseur);
		list.add(planeur);
		
		for(Vehicule v : list) {
			System.out.println(v);
		}
	}
}

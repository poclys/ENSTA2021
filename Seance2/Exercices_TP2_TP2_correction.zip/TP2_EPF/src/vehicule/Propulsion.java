package vehicule;

public enum Propulsion {
	ESSENCE, DIESEL
}

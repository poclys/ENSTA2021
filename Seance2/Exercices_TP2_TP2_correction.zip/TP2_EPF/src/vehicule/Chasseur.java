package vehicule;

public class Chasseur extends Avion implements Motorise {
	protected int puissance;

	public Chasseur(String modele, int nombrePlaces, float poids, int altitudeMax) {
		this(modele, nombrePlaces, poids, altitudeMax, 1);
	}

	public Chasseur(String modele, int nombrePlaces, float poids, int altitudeMax, int puissance) {
		super(modele, nombrePlaces, poids, altitudeMax);
		this.puissance = puissance;
	}


	public int getPuissance() {
		return puissance;
	}

	public void setPuissance(int puissance) {
		this.puissance = puissance;
	}

	@Override
	public float getConsommation() {
		return puissance / poids;
	}

	@Override
	public String toString() {
		return "Chasseur(modele=" + modele +
				", nombrePlaces=" + nombrePlaces +
				", poids=" + poids +
				", altitudeMax=" + altitudeMax +
				", puissance=" + puissance +
				", consommation=" + getConsommation() + ")";
	}

}

package vehicule;

public class Voiture extends Vehicule implements Motorise {
	protected int nombrePortes;
	protected Propulsion propulsion;
	protected int puissance;


	public Voiture(String modele, int nombrePlaces, float poids, int nombrePortes) {
		this(modele, nombrePlaces, poids, nombrePortes, Propulsion.ESSENCE);
	}

	public Voiture(String modele, int nombrePlaces, float poids, int nombrePortes, Propulsion propulsion) {
		this(modele, nombrePlaces, poids, nombrePortes, propulsion, 1);
	}

	public Voiture(String modele, int nombrePlaces, float poids, int nombrePortes, Propulsion propulsion, int puissance) {
		super(modele, nombrePlaces, poids);
		this.nombrePortes = nombrePortes;
		this.propulsion = propulsion;
		this.puissance = puissance;
	}


	public int getNombrePortes() {
		return nombrePortes;
	}

	public Propulsion getPropulsion() {
		return propulsion;
	}

	public int getPuissance() {
		return puissance;
	}
	public void setNombrePortes(int nombrePortes) {
		this.nombrePortes = nombrePortes;
	}

	public void setPropulsion(Propulsion propulsion) {
		this.propulsion = propulsion;
	}

	public void setPuissance(int puissance) {
		this.puissance = puissance;
	}

	@Override
	public String toString() {
		return "Voiture(modele=" + modele +
				", nombrePlaces=" + nombrePlaces +
				", poids=" + poids +
				", nombrePortes=" + nombrePortes +
				", puissance=" + puissance +
				", propulsion=" + propulsion +
				", consommation=" + getConsommation() + ")";
	}

	@Override
	public float getConsommation() {
		int multiplicateur;
		switch (this.propulsion) {
			case ESSENCE:
				multiplicateur = 5;
				break;
			case DIESEL:
				multiplicateur = 3;
				break;
			default:
				multiplicateur = 1;
		}

		return (puissance * multiplicateur) / poids;
	}

}

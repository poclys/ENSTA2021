package vehicule;

public class Avion extends Vehicule {
	protected int altitudeMax;
	
	public Avion(String modele, int nombrePlaces, float poids, int altitudeMax) {
		super(modele, nombrePlaces, poids);
		this.altitudeMax = altitudeMax;
	}

	public int getAltitudeMax() {
		return altitudeMax;
	}

	public void setAltitudeMax(int altitudeMax) {
		this.altitudeMax = altitudeMax;
	}

	@Override
	public String toString() {
		return "Avion(modele="+modele+
				", nombrePlaces="+nombrePlaces+
				", poids="+poids+
				", altitudeMax="+altitudeMax+")";
	}

}

package vehicule;

public interface Motorise {
	public float getConsommation();
}

package com.app.service.impl;

import java.util.ArrayList;
import java.util.List;

import com.app.dao.IFilmDao;
import com.app.dao.impl.FilmDao;
import com.app.exception.DaoException;
import com.app.exception.ServiceException;
import com.app.model.Film;
import com.app.service.IFilmService;


/*
 * Ici, comme dans le tp, le Service est une classe qui va impl�menter une interface (ici IFilmService)
 * qui d�fini plusieurs m�thode qui s'inspire du CRUD. G�n�ralement, on r�cup�rera les donn�es brut
 * venues de la Servlets pour construire les objets de type Film au sein de ce Service.
 * Cette �tape est appel�e Mapping. C'est ici que les champs sont v�rifier.
 * Les bonnes pratiques sont d'encapsuler les diff�rentes exceptionss qui peuvent �tre lev�es 
 * ici: (NullPointer, ParseException, ...) dans nos propres classes d'exceptions (ServiceExecption). 
 * Ce sont ces derni�res exceptions que nous pourront lancer vers la Servlet. Pour les exceptions 
 * DaoException, on n'�vitera de les laisser remonter.
 */
public class FilmService implements IFilmService {
	
	// Une autre impl�mentation possible du design pattern Singleton
	private static FilmService instance = new FilmService();
	private FilmService() { }	
	public static IFilmService getInstance() {		
		return instance;
	}
	

	@Override
	public int create(String titre, String realisateur) throws ServiceException {
		Film film = new Film(titre, realisateur);
		IFilmDao filmDao = FilmDao.getInstance();
		int i = -1;
		try {
			i = filmDao.create(film);
		}  catch (DaoException e1) {
			System.out.println(e1.getMessage());			
		} 
		return i;
	}
	

	@Override
	public Film getFilm(String id) throws ServiceException {
		try {
			int i = Integer.parseInt(id);
			return getFilm(i);
		} catch (NumberFormatException e2) {
			throw new ServiceException("Erreur lors du parsing: id=" + id, e2);
		} 
	}
	
	@Override
	public Film getFilm(int id) throws ServiceException {
		IFilmDao filmDao = FilmDao.getInstance();
		Film film = new Film();
		try {
			film = filmDao.getFilm(id);
		} catch (DaoException e1) {
			System.out.println(e1.getMessage());			
		}
		return film;
	}
	
	@Override
	public List<Film> getFilms() {
		IFilmDao filmDao = FilmDao.getInstance();
		List<Film> films = new ArrayList<>();		
		try {
			films = filmDao.getFilms();
		} catch (DaoException e1) {
			System.out.println(e1.getMessage());			
		}
		return films;
	}
	
	@Override
	public int update(String id, String titre, String realisateur) throws ServiceException {
		IFilmDao filmDao = FilmDao.getInstance();
		int i = -1;
		try {
			Film film = new Film(Integer.parseInt(id), titre, realisateur);
			i = filmDao.update(film);
		} catch (DaoException e1) {
			System.out.println(e1.getMessage());			
		} catch (NumberFormatException e2) {
			throw new ServiceException("Erreur lors du parsing: id=" + id, e2);
		}
		return i;
	}


	@Override
	public int delete(String id) throws ServiceException {
		IFilmDao filmDao = FilmDao.getInstance();
		int i = -1;
		try {
			Film film = filmDao.getFilm(Integer.parseInt(id));
			i = filmDao.delete(film);
		} catch (DaoException e1) {
			System.out.println(e1.getMessage());			
		} catch (NumberFormatException e2) {
			throw new ServiceException("Erreur lors du parsing: id=" + id, e2);
		}
		return i;
	}

}

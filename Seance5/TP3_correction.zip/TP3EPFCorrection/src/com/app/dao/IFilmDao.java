package com.app.dao;

import java.util.List;

import com.app.exception.DaoException;
import com.app.model.Film;

public interface IFilmDao {

	int create(Film film) throws DaoException;
	
	Film getFilm(int id) throws DaoException;
	
	List<Film> getFilms() throws DaoException;
	
	int update(Film film) throws DaoException;
	
	int delete(Film film) throws DaoException;		
}

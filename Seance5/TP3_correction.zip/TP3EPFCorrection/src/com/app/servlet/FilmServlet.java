package com.app.servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.app.exception.ServiceException;
import com.app.model.Film;
import com.app.service.IFilmService;
import com.app.service.impl.FilmService;

public class FilmServlet extends HttpServlet {	
	
	/*
	 *  La m�thode doGet est le point d'entr�e lors d'une requete GET
	 *  Dans notre cas on traite tous les cas de figure en passant par doGet
	 *  Cependant pour vraiment respecter les conventions Http, il est de bonne pratique
	 *  de g�rer les suppressions dans la m�thode doDelete, les modification dans la m�thode
	 *  doPut etc ...
	 *  A noter qu'il existe des "logger" pour remplacer nos "Sysout" (System.out.println) qui permettent 
	 *  de formatter l'affichage lors du d�bug dans la console (Affichant la date, l'heure, la classe dans 
	 *  laquelle le logger effectue l'affichage). Plusieurs niveaux d'affichage peuvent �tre utilis�s 
	 *  (info, debug, error, warn, etc...).
	 */
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String action = request.getServletPath();
		switch (action) {
			case "/new":
				showAddForm(request, response);
				break;
			case "/insert":
				insert(request, response);
				break;
			case "/delete":
				delete(request, response);
				break;
			case "/edit":
				showEditForm(request, response);
				break;
			case "/update":
				update(request, response);
				break;
			case "/list":
				showAllFilm(request, response);
				break;
			case "/listJSTL":
				showAllFilmJSTL(request, response);
				break;				
			case "/index":
				showPublicIndex(request, response);
				break;
			case "/pindex":
				showPrivateIndex(request, response);
				break;
			default:
				System.out.println("Default redirecting case from " + action + " !");
				showAllFilm(request, response);
		}
	}
	
	/*
	 * Cette m�thode r�cup�re la liste des films puis redirige vers une page JSP 
	 * qui exploite l'utilisation des scriptlets pour cr�er la page html.
	 */
	private void showAllFilm(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		IFilmService filmService = FilmService.getInstance();
		List<Film> films = new ArrayList<>();
		try {
			films = filmService.getFilms();
		} catch (ServiceException e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
		request.setAttribute("films", films);
		RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/view/listFilm.jsp");
		dispatcher.forward(request, response);
	}
	
	/*
	 * Cette m�thode r�cup�re la liste des films puis redirige vers une page JSP 
	 * qui exploite l'utilisation des taglibs pour cr�er la page html
	 * Les taglibs sont des balises sp�ciales au format html qui permettent d'effectuer
	 * des op�rations de base (if, for, switch, d�claration de variables).
	 * Elles pr�servent la JSP d'un m�lange de deux langages diff�rent (html vs scriptlets Java)
	 */
	private void showAllFilmJSTL(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		IFilmService filmService = FilmService.getInstance();
		List<Film> films = new ArrayList<>();
		try {
			films = filmService.getFilms();
		} catch (ServiceException e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
		RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/view/listFilmJSTL.jsp");
		request.setAttribute("films", films);
		dispatcher.forward(request, response);
	}

	/*
	 * Cette m�thode r�cup�re l'id du film s�lectionn� sur la page listFilm
	 * et redirige sur la JSP "editForm.jsp" avec le film pr�c�demment choisi en attribut
	 * Il s'agit de l'affichage de la page.
	 */
	private void showEditForm(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		IFilmService filmService = FilmService.getInstance();
		String inputId = request.getParameter("id");
		Film film = new Film();
		try {
			film = filmService.getFilm(inputId);
		} catch (ServiceException e) {
			System.out.println(e.getMessage());
			e.printStackTrace();

		}		
		request.setAttribute("film", film);
		RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/view/editFilm.jsp");
		dispatcher.forward(request, response);
	}

	/*
	 * Cette m�thode r�cup�re l'id (contenue dans l'URI), le titre et le r�alisateur du film
	 * (contenue dans les param�tres de formulaire via les noms "titre" et "realisateur") 
	 * et redirige sur la m�me JSP avec le film pr�c�demment modifi� en attribut. 
	 * Dans la JSP les formulaires et l'URI seront explicitement rempli avec les bonnes valeurs (cf editForm.jsp)
	 * Cette m�thode est appel�e lors d'un clique sur le bouton "Enregister".
	 */
	private void update(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		IFilmService filmService = FilmService.getInstance();
		String inputId = request.getParameter("id");
		String inputTitre = request.getParameter("titre");
		String inputRealisateur = request.getParameter("realisateur");
		Film film;
		try {
			int id = filmService.update(inputId, inputTitre, inputRealisateur);
			 film = filmService.getFilm(id);
		} catch (ServiceException e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
			film = new Film();
		}
		
		request.setAttribute("film", film);
		RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/view/editFilm.jsp");
		dispatcher.forward(request, response);		
	}

	/*
	 * Cette m�thode affiche une page de formulaire � remplir
	 * Dans la JSP les formulaires et l'URI seront � remplir par l'utilisateur.
	 * Cette m�thode est appel�e lors d'un click sur le lien principal "Add New Films"
	 */
	private void showAddForm(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/view/createFilm.jsp");
		dispatcher.forward(request, response);		
	}
	
	
	/*
	 * On r�cup�re des formulaires cot� jsp les entr�es utilisateurs 'titre' et 'realisateur' 
	 * puis on appelle le service qui va se charger de construire l'objet film.
	 * Enfin au choix on peut rediriger vers la jsp 'create', 'edit' ou 'list' en fonction 
	 * des meilleurs pratique User Experience, par exemple si l'utilisateur souhaite corriger
	 * des valeurs pour le film qu'il vient d'ajouter.
	 */
	private void insert(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		IFilmService filmService = FilmService.getInstance();
		String inputTitre = request.getParameter("titre");
		String inputRealisateur = request.getParameter("realisateur");
		Film film;
		try {
			int id = filmService.create(inputTitre, inputRealisateur);
			film = filmService.getFilm(id);
		} catch (ServiceException e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
			film = new Film();
		}
		
		request.setAttribute("film", film);
		RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/view/editFilm.jsp");
		dispatcher.forward(request, response);		
	}
	
	
	/*
	 * La m�thode delete supprime un film de la liste des films.
	 * Elle r�cup�re l'id qui est int�grer � l'URI (cf listFilm.jsp/listFilmJSTL.jsp)
	 * et appelle le service pour supprimer le film concern�.
	 * Remarque: vous constatez que les m�thodes de modification et de suppression
	 * retourne une valeur de type Integer (en faite l'id du film). Pour respecter la normes HTTP
	 * on doit normalement retourner un code HTTP en fonction de l'action effectuer, plus eventuellement 
	 * l'identifiant de la ressource alt�rer. (cf. Wiki: Code de retour HTTP)
	 */
	private void delete(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		IFilmService filmService = FilmService.getInstance();
		String inputId = request.getParameter("id");
		try {
			int id = filmService.delete(inputId);
		} catch (ServiceException e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
		
		RequestDispatcher dispatcher = request.getRequestDispatcher("/");
		dispatcher.forward(request, response);
	}
	
	/*
	 * Les deux m�thodes sont la pour mettre en avant un point que nous avont vu en cours
	 * � savoir l'accessibilit� du client � certaines ressource en fonction de leur 
	 * emplacement dans les dossiers de l'application.
	 */
	private void showPublicIndex(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		RequestDispatcher dispatcher = request.getRequestDispatcher("/public/index.jsp");
		dispatcher.forward(request, response);		
	}
	
	private void showPrivateIndex(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/view/index.jsp");
		dispatcher.forward(request, response);		
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}

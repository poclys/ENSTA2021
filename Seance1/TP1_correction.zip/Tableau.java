import java.util.Arrays;

class Tableau {
    /*
     * Méthode publique permettant d'exécuter l'algorithme de tri rapide sur l'ensemble du tableau passé en argument
     */
    public static void triRapide(int[] array) {
        int len = array.length;
        triRapideAux(array, 0, len - 1);
    }

    /*
     * Fonction auxiliaire utilisée par triRapide.
     * Cette méthode est privée car on ne veut pas permettre son utilisation autrement qu'en passant par la méthode triRapide.
     */
    private static void triRapideAux(int[] array, int begin, int end) {
        if (begin < end) {
            int pivot = partition(array, begin, end);
            triRapideAux(array, begin, pivot - 1);
            triRapideAux(array, pivot + 1, end);
        }
    }

    /*
     * Fonction auxiliaire utilisée par triRapideAux.
     * Cette méthode est privée pour les mêmes raisons que triRapideAux.
     */
    private static int partition(int[] array, int begin, int end) {
        int pivot = array[begin];
        int _begin = begin;
        int _end = end;

        while (_begin < _end) {
            while(_begin < _end && array[_end] >= pivot) {
                _end--;
            }

            while(_begin < _end && array[_end] <= pivot) {
                _begin++;
            }

            int swap = array[_begin];
            array[_begin]= array[_end];
            array[_end] = swap;
        }

        if (array[_begin] > pivot) _begin--;
        array[begin] = array[_begin];
        array[_begin] = pivot;
        return _begin;
    }

    public static void main(String[] args) {
        int[] intArray = new int[] {27, 12, 1515, 42, 384};

        System.out.println("Tableau avant tri rapide : " + Arrays.toString(intArray));
        triRapide(intArray);
        System.out.println("Tableau trié : " + Arrays.toString(intArray));
    }
}

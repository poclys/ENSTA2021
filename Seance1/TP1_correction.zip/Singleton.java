public class Singleton {
    /*
     * Unique instance du Singleton pour l'ensemble du programme. 
     */
    private static Singleton instance;

    /*
     * Constructeur privé, qui ne peut être appelé qu'à l'intérieur de la classe.
     * Cela empêche de créer une instance de Singleton n'importe où dans le programme à l'aide de new.
     */
    private Singleton() {}

    /*
     * Méthode permettant de renvoyer une référence vers l'instance unique du Singleton.
     * C'est le seul moyen pour obtenir un Singleton dans tout le programme.
     */
    public static Singleton getInstance() {
        if(instance == null) {
            instance = new Singleton();
        }
        return instance;
    }

    public static void main(String[] args) {
        Singleton s1 = Singleton.getInstance();
        Singleton s2 = Singleton.getInstance();
        Singleton s3 = s1;

        System.out.println(s1 == s3); // true, par définition de s3
        System.out.println(s1 == s2); // true, car getInstance() renvoie une référence vers la même instance de Singleton
    }
}

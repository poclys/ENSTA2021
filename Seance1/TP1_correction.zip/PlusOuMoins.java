import java.util.Scanner;
import java.util.Random;

public class PlusOuMoins {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int nombreMystere = new Random().nextInt(101); // nextInt(x) retourne un entier entre 0 et (x-1) inclus

        System.out.println("Entrez un nombre entre 1 et 100 inclus");

        int essaisRestants = 20;
        int proposition;
        do {
            proposition = scanner.nextInt();

            if (proposition < 1 || proposition > 100) {
                System.out.println("Le nombre doit être compris entre 1 et 100 inclus");
                essaisRestants--;
            } else if (proposition < nombreMystere) {
                System.out.println("Le nombre cherché est plus grand");
                essaisRestants--;
            } else if (proposition > nombreMystere) {
                System.out.println("Le nombre cherché est plus petit");
                essaisRestants--;
           }
        } while (proposition != nombreMystere && essaisRestants > 0);

        if (essaisRestants > 0) {
            System.out.println("BRAVO ! Le nombre mystère était " + nombreMystere);
        } else {
            System.out.println("Dommage, il ne te reste plus d'essai.\nLe nombre mystère était " + nombreMystere);
        }
    }
}
